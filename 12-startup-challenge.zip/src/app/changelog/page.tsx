import fs from "node:fs";
import path from "node:path";
import UpdateCard from "@/components/UpdateCard";

export const dynamic = "force-static";

type Update = {
  date: string;
  title: string;
  body: string;
  tags?: string[];
};

export default function ChangelogPage() {
  const file = path.join(process.cwd(), "src", "data", "updates.json");
  const raw = fs.readFileSync(file, "utf8");
  const updates: Update[] = JSON.parse(raw);
  updates.sort((a, b) => (a.date < b.date ? 1 : -1));

  return (
    <main className="section">
      <div className="container-page space-y-6">
        <header className="text-center mb-6">
          <h1 className="text-4xl font-black">📜 Changelog</h1>
          <p className="text-gray-600 mt-2">Honest, messy updates as I ship 12 startups in 12 months.</p>
        </header>
        <div className="grid gap-4">
          {updates.map((u, i) => (<UpdateCard key={i} {...u} />))}
        </div>
        <footer className="text-center text-sm text-gray-500 mt-10">
          Edit <code>src/data/updates.json</code> to add an entry, then redeploy.
        </footer>
      </div>
    </main>
  );
}
