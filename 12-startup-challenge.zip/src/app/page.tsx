import ScoreboardCard from "@/components/ScoreboardCard";
import UpdateCard from "@/components/UpdateCard";
import MetricsWidget from "@/components/MetricsWidget";
import BuyButton from "@/components/BuyButton";
import { projects } from "@/data/projects";
import updates from "@/data/updates.json";

export default function Page() {
  return (
    <main>
      <section className="hero">
        <div className="container-page">
          <h1 className="text-5xl font-black mb-4">🚀 The 12 Startup Challenge</h1>
          <p className="text-xl opacity-90">Built in Public. No Code Background. Full Code. No Excuses.</p>
          <p className="mt-6 text-lg opacity-80 max-w-3xl mx-auto">
            I’m a 47-year-old husband and dad seeing if an ordinary guy with no
            coding background can ship 12 real startups in 12 months—using AI,
            open source, and whatever cheap tools the internet throws at me.
          </p>
          <p className="mt-6"><BuyButton label="Tip the build ($5)" /></p>
          <p className="mt-4">
            <a href="/changelog" className="underline underline-offset-4">Read the changelog →</a>
          </p>
        </div>
      </section>

      <section className="section container-page">
        <h2 className="text-3xl font-bold mb-4">Before Anything Else</h2>
        <p className="mb-2">I need to give credit where it’s due:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Peter Levels</strong> lit the spark…</li>
          <li><strong>Lex Fridman</strong> has been the fuel…</li>
        </ul>
        <p className="mt-4">Without them, I wouldn’t even be here writing this.</p>
      </section>

      <section className="section-muted">
        <div className="container-page space-y-12">
          <div>
            <h2 className="text-3xl font-bold mb-4">Who I Am</h2>
            <p className="mb-4">
              I’m not a coder. I’m not rich. I’m not a genius. I’m just a 47-year-old husband and dad who has
              worked my butt off in jobs where I try to help people — but never really made much. I drive a $2,000 car,
              I shop Walmart clearance, and if I’ve got $20 cash, it’s usually for a haircut.
            </p>
            <p className="mb-4">
              To be totally transparent — I am not poor. I live frugally, my wife does too, and my kids enjoy travel and
              education at a level I can afford without risking the investments I’ve made over the years. I’m grateful for that.
              But day to day, I still live like an ordinary guy trying to stretch every dollar.
            </p>
            <p>
              Over the past few years, I’ve learned bits and pieces of tech, AI, SaaS, and coding. I’ve built dozens of
              half-finished projects with the help of LLMs… and I’ve never made a dime from any of them. Not one.
            </p>
          </div>

          <div>
            <h2 className="text-3xl font-bold mb-4">To the Haters</h2>
            <p className="mb-4">Bring it.</p>
            <p className="mb-4">
              Yes — this announcement was written with ChatGPT. No ego, no bravado. The real question is:
              <em> can a complete tech outsider use AI, open source, and scraps to make money online?</em>
            </p>
            <p>
              I’m copying the <strong>12 Startups in 12 Months</strong> idea, not the starting point.
              I’m less savvy and know less. If I succeed, it will show how much AI closed the gap.
            </p>
          </div>

          <div>
            <h2 className="text-3xl font-bold mb-4">What Makes This Different</h2>
            <p className="mb-4">
              This is <strong>not</strong> a no-code demo. I’m going full code. Open source. Cheap tools.
              Whatever the hell I can get my hands on.
            </p>
            <p className="mb-4">
              Tech is finally simple enough that even a guy like me can build real products — not because I’m special,
              but because the tools are. Maybe I’m too optimistic about technology. That’s the point of this challenge.
            </p>
            <p className="mb-4">
              I’m not selling you anything. I’ll charge for the apps I make so they stay real. Income goes back into hosting,
              APIs, or new ideas. If there’s profit? I’ll keep it. No charity. No courses. No gimmicks. Just clear reporting.
            </p>
          </div>

          <div>
            <h2 className="text-3xl font-bold mb-4">The Rules</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>12 startups in 12 months</li>
              <li>Built in public — mistakes, blunders, failures, wins</li>
              <li>Full transparency: costs, revenue, lessons</li>
              <li>No polish, no hiding</li>
              <li>If I succeed, you’ll know you can too</li>
            </ul>
          </div>

          <div>
            <h2 className="text-3xl font-bold mb-4">Real Life Disclaimer</h2>
            <p>
              I’m doing this while working and living my real life. Expect a sporadic, messy, limited reporting schedule.
              Sorry, life.
            </p>
          </div>

          <div>
            <h2 className="text-3xl font-bold mb-4">Who This Is For</h2>
            <p>
              Not for flashy builders — for the tired, scared, and determined. If I can do this, so can you.
            </p>
          </div>
        </div>
      </section>

      <section className="section container-page">
        <h2 className="text-3xl font-bold mb-4">📈 Live Metrics</h2>
        <MetricsWidget />
      </section>

      <section className="section bg-gray-900 text-white">
        <div className="container-page">
          <h2 className="text-4xl font-bold text-center mb-10">📊 Scoreboard</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {projects.map((p) => (
              <ScoreboardCard key={p.number} {...p} />
            ))}
          </div>
        </div>
      </section>

      <section className="section container-page">
        <h2 className="text-3xl font-bold mb-4">Recent Updates</h2>
        <div className="grid gap-4">
          {(updates as any[]).map((u, i) => (
            <UpdateCard key={i} {...u} />
          ))}
        </div>
        <p className="mt-6">
          <a href="/changelog" className="underline underline-offset-4">See all updates →</a>
        </p>
      </section>

      <section className="section text-center">
        <div className="container-page">
          <h2 className="text-3xl font-bold mb-4">Here we go.</h2>
          <p className="text-lg text-gray-700 max-w-2xl mx-auto">
            I’m building 12 startups in 12 months. Public, messy, full code. Follow along for the mistakes,
            the blunders, and maybe — the wins.
          </p>
        </div>
      </section>
    </main>
  );
}
