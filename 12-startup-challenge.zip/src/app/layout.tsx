import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "The 12 Startup Challenge — Built in Public",
  description: "A regular guy ships 12 full-code startups in 12 months. Public, messy, transparent.",
  openGraph: {
    title: "The 12 Startup Challenge — Built in Public",
    description: "A regular guy ships 12 full-code startups in 12 months. Public, messy, transparent.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "The 12 Startup Challenge — Built in Public",
    description: "A regular guy ships 12 full-code startups in 12 months. Public, messy, transparent.",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
