type Props = {
  number: number;
  title: string;
  status: "Planning" | "Building" | "Launched" | "Archived";
  revenue: number;
  href?: string;
};

const statusDot: Record<Props["status"], string> = {
  Planning: "bg-gray-400",
  Building: "bg-yellow-500",
  Launched: "bg-green-600",
  Archived: "bg-red-500",
};

export default function ScoreboardCard({ number, title, status, revenue, href }: Props) {
  const content = (
    <div className="card p-5 h-full">
      <div className="flex items-center justify-between mb-3">
        <span className="badge border-gray-300 text-gray-600">Project #{number}</span>
        <span className="inline-flex items-center gap-2 text-sm">
          <span className={`inline-block h-2.5 w-2.5 rounded-full ${statusDot[status]}`} />
          {status}
        </span>
      </div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-4 text-sm text-gray-600">
        Revenue: <span className="font-semibold">${revenue}</span>
      </p>
    </div>
  );
  return href ? (
    <a href={href} className="block h-full hover:-translate-y-0.5 transition">{content}</a>
  ) : content;
}
