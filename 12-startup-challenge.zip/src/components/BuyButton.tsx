export default function BuyButton({ label = "Tip the build ($5)" }: { label?: string }) {
  const url = process.env.NEXT_PUBLIC_PAYMENT_LINK || "#";
  return (
    <a
      href={url}
      className="inline-flex items-center gap-2 rounded-lg bg-black text-white px-4 py-2 hover:opacity-90"
      rel="noopener noreferrer"
      target={url.startsWith("http") ? "_blank" : undefined}
    >
      {label}
    </a>
  );
}
