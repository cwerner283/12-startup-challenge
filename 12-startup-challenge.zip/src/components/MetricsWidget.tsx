import metrics from "@/data/metrics.json";

function MetricCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="card p-5">
      <div className="text-sm text-gray-500">{label}</div>
      <div className="text-2xl font-semibold mt-1">{value}</div>
    </div>
  );
}

export default function MetricsWidget() {
  const m = metrics;
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <MetricCard label="MRR" value={`$${m.mrr_usd}`} />
      <MetricCard label="Total Orders" value={m.total_orders} />
      <MetricCard label="Total Runs" value={m.total_runs} />
      <MetricCard label="Projects Live" value={m.projects_live} />
      <p className="col-span-2 md:col-span-4 text-xs text-gray-500 mt-2">
        Updated: {new Date(m.updated_at).toLocaleString()}
      </p>
    </div>
  );
}
