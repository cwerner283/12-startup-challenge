type Update = {
  date: string;
  title: string;
  body: string;
  tags?: string[];
};

export default function UpdateCard({ date, title, body, tags = [] }: Update) {
  return (
    <article className="card p-5">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">{title}</h3>
        <time className="text-sm text-gray-500">{date}</time>
      </div>
      <p className="mt-3 text-gray-700">{body}</p>
      {tags.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {tags.map((t) => (
            <span key={t} className="badge border-gray-300 text-gray-700 bg-gray-50">#{t}</span>
          ))}
        </div>
      )}
    </article>
  );
}
