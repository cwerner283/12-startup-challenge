export type Project = {
  number: number;
  title: string;
  status: "Planning" | "Building" | "Launched" | "Archived";
  revenue: number;
  href?: string;
};

export const projects: Project[] = [
  { number: 1, title: "Fake Sandalwood Finder", status: "Building", revenue: 0 },
  { number: 2, title: "Viral Score Estimator", status: "Planning", revenue: 0 },
  { number: 3, title: "AI Call Flagging Tool", status: "Planning", revenue: 0 }
];
